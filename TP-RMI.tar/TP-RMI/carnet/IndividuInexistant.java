package carnet;

/** Exception levée par Carnet. */
public class IndividuInexistant extends Exception {
    public IndividuInexistant(String s) {super(s);}
}
