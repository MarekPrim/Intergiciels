package carnet;

import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;
import java.util.*;

/** Implémentation basique d'un Carnet accessible à distance.
 *  Utilise une List(e) pour ranger les Individu(s).
 */
public class CarnetImpl extends UnicastRemoteObject implements Carnet {
    
    private List<Individu> contenu = new ArrayList<Individu>();


    public CarnetImpl() throws RemoteException {}

    /**** A COMPLETER ****/
}
